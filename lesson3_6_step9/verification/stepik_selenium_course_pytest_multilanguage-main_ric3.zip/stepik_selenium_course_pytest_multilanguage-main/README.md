## Домашняя работа по курсу

### Автоматизация тестирования с помощью Selenium и Python

https://stepik.org/course/575/syllabus
